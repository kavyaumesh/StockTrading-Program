#include <stdlib.h>
#include <stdio.h>
#include <assert.h>
#include "../Headers/stock.h"
#include "../Headers/appconst.h"

