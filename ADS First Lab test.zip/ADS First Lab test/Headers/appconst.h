#ifndef APPCONST_H_INCLUDED
#define APPCONST_H_INCLUDED

#define MAX_SHARE 5

#define BUY 1
#define SELL 0

#endif // APPCONST_H_INCLUDED
