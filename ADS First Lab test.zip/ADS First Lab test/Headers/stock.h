#ifndef STOCK_H_INCLUDED
#define STOCK_H_INCLUDED
#include "appconst.h"


typedef _person_share_ PersonShare;

struct _person_share_{
  char sharename[20];
  char date[10];
  float price;
  int32_t quantity;
  
};

typedef _transactions_ Transactions;

struct _person_share_{
  char companyname[20];
  date date[10];
  float price;
  int32_t quantity;
  int8_t transactiontype;
  
};

typedef _node_ Node;

struct _node_{
  PersonShare data;
  Node *next;
}


typedef _tradingq_ TradingQ;

struct _tradingq_{
  Node *rear; 
  Node *front
  uint32_t length;
}

TradingQ tradingq_new();
uint32_t tradingq_length(const TradingQ *tradingq);
uint32_t tradingq_lookup(const TradingQ *tradingq);
TradingQ* tradingq_addnode_rear(TradingQ *tradingq, int32_t val);
TradingQ* tradingq_delnode_front(TradingQ *tradingq);
TradingQ* tradingq_modify(TradingQ *tradingq, int32_t newshare);
                                              
#endif // STOCK_H_INCLUDED
